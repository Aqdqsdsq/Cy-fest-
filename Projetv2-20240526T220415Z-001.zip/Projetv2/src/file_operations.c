#include "file_operations.h"
#include "types.h"
#include <stdio.h>
#include <stdlib.h>

// Enregistre les données des salles de concert dans un fichier.
void saveDataToFile() {
    // Tente d'ouvrir le fichier pour l'écriture en mode binaire.
    FILE *file = fopen("halls.dat", "wb");
    // Vérifie si le fichier a été ouvert avec succès.
    if (!file) {
        // Affiche l'erreur et termine le programme si le fichier ne peut pas être ouvert.
        perror("Erreur lors de l'ouverture du fichier pour sauvegarde");
        exit(EXIT_FAILURE);
    }

    // Écrit le nombre de salles dans le fichier.
    fwrite(&numHalls, sizeof(int), 1, file);
    // Itère sur chaque salle pour enregistrer ses données.
    for (int i = 0; i < numHalls; i++) {
        // Enregistre les données structurées de la salle.
        fwrite(halls[i], sizeof(ConcertHall), 1, file);
        // Enregistre le nombre de sièges par rangée.
        fwrite(halls[i]->numSeatsPerRow, sizeof(int), halls[i]->numRows, file);
        // Itère sur chaque rangée pour enregistrer les sièges.
        for (int j = 0; j < halls[i]->numRows; j++) {
            // Enregistre les données de chaque siège.
            fwrite(halls[i]->seats[j], sizeof(Seat), halls[i]->numSeatsPerRow[j], file);
        }
    }
    // Ferme le fichier après l'enregistrement.
    fclose(file);
}

### Fonction `loadDataFromFile`
```c
// Charge les données des salles de concert depuis un fichier.
void loadDataFromFile() {
    // Tente d'ouvrir le fichier en mode lecture binaire.
    FILE *file = fopen("halls.dat", "rb");
    // Vérifie si le fichier est ouvert avec succès.
    if (!file) {
        // Affiche un message si le fichier n'est pas trouvé et initialise les données.
        printf("Fichier de données introuvable. Initialisation avec des données de salle vides.\n");
        return;
    }

    // Lit le nombre de salles depuis le fichier.
    fread(&numHalls, sizeof(int), 1, file);
    // Alloue la mémoire pour le tableau de pointeurs de salles.
    halls = malloc(numHalls * sizeof(ConcertHall*));
    // Vérifie l'allocation mémoire.
    if (halls == NULL) {
        fprintf(stderr, "Failed to allocate memory for halls\n");
        // Nettoie la mémoire si l'allocation échoue pour éviter les fuites de mémoire.
        for (int j = 0; j < i; j++) {
            if (halls[j]->seats) {
                for (int k = 0; k < halls[j]->numRows; k++) {
                    free(halls[j]->seats[k]);
                }
                free(halls[j]->seats);
            }
            free(halls[j]->numSeatsPerRow);
            free(halls[j]);
        }
        free(halls);
        halls = NULL;
        return;
    }

    // Lit et alloue la mémoire pour chaque salle.
    for (int i = 0; i < numHalls; i++) {
        halls[i] = malloc(sizeof(ConcertHall));
        // Vérifie l'allocation mémoire pour chaque salle.
        if (halls[i] == NULL) {
            fprintf(stderr, "Failed to allocate memory for hall %d\n", i);
            exit(EXIT_FAILURE);
        }
        fread(halls[i], sizeof(ConcertHall), 1, file);
        halls[i]->numSeatsPerRow = malloc(sizeof(int) * halls[i]->numRows);
        halls[i]->seats = malloc(sizeof(Seat*) * halls[i]->numRows);
        for (int j = 0; j < halls[i]->numRows; j++) {
            halls[i]->seats[j] = malloc(sizeof(Seat) * halls[i]->numSeatsPerRow[j]);
            fread(halls[i]->seats[j], sizeof(Seat), halls[i]->numSeatsPerRow[j], file);
        }
    }
    // Ferme le fichier après le chargement des données.
    fclose(file);
}