#ifndef INPUT_UTILS_H
#define INPUT_UTILS_H

// input_utils.h
// Ce fichier définit des fonctions utilitaires pour la gestion des entrées utilisateur.
// Il inclut des fonctions pour nettoyer le tampon d'entrée et pour récupérer des entrées
// validées de type int et double.

// Vide le tampon d'entrée pour éviter des erreurs de lecture ultérieures.
// Cette fonction doit être appelée après des saisies utilisateur pour s'assurer que 
// tout caractère résiduel (comme les sauts de ligne) soit consommé et ne perturbe pas
// les lectures futures.
void clearInputBuffer();

// Demande et valide une entrée de type int de l'utilisateur.
// Paramètres:
//   - prompt: Message affiché à l'utilisateur pour demander l'entrée.
//   - min: Valeur minimale autorisée pour l'entrée.
//   - max: Valeur maximale autorisée pour l'entrée.
// Retourne:
//   - Un entier compris entre min et max après validation.
// Cette fonction affiche 'prompt', puis lit l'entrée de l'utilisateur. Elle valide que l'entrée
// est un entier dans l'intervalle [min, max]. Si l'entrée est invalide, elle invite de nouveau 
// l'utilisateur jusqu'à obtenir une entrée valide.
int getIntInput(const char *prompt, int min, int max);

// Demande et valide une entrée de type double de l'utilisateur.
// Paramètres:
//   - prompt: Message affiché à l'utilisateur pour demander l'entrée.
//   - min: Valeur minimale autorisée pour l'entrée.
//   - max: Valeur maximale autorisée pour l'entrée.
// Retourne:
//   - Un double compris entre min et max après validation.
// Fonctionne de manière similaire à getIntInput mais pour des entrées de type double,
// permettant une précision plus grande pour des valeurs décimales.
double getDoubleInput(const char *prompt, double min, double max);

#endif // INPUT_UTILS_H