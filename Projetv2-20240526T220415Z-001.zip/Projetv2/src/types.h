#ifndef TYPES_H
#define TYPES_H

#include <time.h>

// Constantes pour la taille des noms et les limites du système.
#define MAX_NAME_LEN 50  // Longueur maximale des noms (salles, concerts).
#define MAX_HALLS 10  // Nombre maximal de salles que le système peut gérer.
#define MAX_SEATS_PER_ROW 100  // Nombre maximal de sièges par rangée.

// Catégories de sièges.
#define CATEGORY_A 'A'  // Catégorie A pour les sièges premium.
#define CATEGORY_B 'B'  // Catégorie B pour les sièges standard.
#define CATEGORY_C 'C'  // Catégorie C pour les sièges économiques.

// Codes de couleur pour l'affichage.
#define COLOR_RED "\x1B[31m"  // Code de couleur rouge pour les sièges réservés.
#define COLOR_GREEN "\x1B[32m"  // Code de couleur vert.
#define COLOR_YELLOW "\x1B[33m"  // Code de couleur jaune.
#define COLOR_RESET "\x1B[0m"  // Réinitialisation de la couleur.

/// Structure représentant un siège dans une salle de concert.
typedef struct {
    int reserved;  // Indicateur si le siège est réservé (1) ou non (0).
    double price;  // Prix du siège.
    char category;  // Catégorie du siège (A, B, ou C).
} Seat;

/// Structure représentant un concert.
typedef struct {
    char name[MAX_NAME_LEN];  // Nom du concert.
    time_t endTime;  // Heure de fin du concert.
} Concert;

/// Structure représentant une salle de concert.
typedef struct {
    char name[MAX_NAME_LEN];  // Nom de la salle de concert.
    int numRows;  // Nombre de rangées dans la salle.
    int *numSeatsPerRow;  // Tableau dynamique contenant le nombre de sièges par rangée.
    Seat **seats;  // Tableau dynamique de tableaux de sièges.
    int rowsCategoryA;  // Nombre de rangées pour la catégorie A.
    int rowsCategoryB;  // Nombre de rangées pour la catégorie B.
    int hasPit;  // Indicateur si la salle a une fosse (1) ou non (0).
    Concert *concert;  // Pointeur vers le concert planifié dans cette salle (peut être NULL).
} ConcertHall;

// Variables globales externes.
extern ConcertHall **halls;  // Tableau de pointeurs vers les salles de concert gérées.
extern int numHalls;  // Nombre de salles de concert actuellement gérées.
ConcertHall**halls;

#endif // TYPES_H