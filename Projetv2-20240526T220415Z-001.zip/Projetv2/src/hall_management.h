#ifndef HALL_MANAGEMENT_H
#define HALL_MANAGEMENT_H

// Inclusion des types structurés utilisés dans les déclarations des fonctions.
#include "types.h"

// Prototypes des fonctions pour la gestion des salles de concerts.

// Crée une nouvelle salle de concert.
// Demande à l'utilisateur d'entrer les informations de la salle, la crée, et l'ajoute à la liste des salles.
void createConcertHall();

// Attribue un concert à une salle spécifiée.
// Cette fonction est prévue pour associer des concerts à des salles disponibles, gérant également les conflits d'horaire.
void assignConcertToHall();

// Libère les ressources allouées à une salle de concert.
// Prend en paramètre un pointeur vers la salle à libérer et s'occupe de la libération de tous ses composants dynamiques.
void freeConcertHall(ConcertHall *hall);

// Modifie les attributs d'une salle après un concert.
// Peut être utilisée pour la maintenance ou la mise à jour des informations liées à la salle après des événements.
void modifyHallAfterConcert();

// Initialise les sièges d'une rangée spécifique dans une salle donnée.
// Paramètres: hall (salle concernée), row (rangée à initialiser), category (catégorie des sièges), price (prix des sièges).
// Cette fonction configure chaque siège de la rangée avec les attributs fournis.
void initializeSeats(ConcertHall *hall, int row, char category, double price);

// Met à jour les prix des sièges pour les différentes catégories dans une salle donnée.
// Paramètres: hall (salle concernée), priceA, priceB, priceC (nouveaux prix pour les catégories A, B, et C).
// Applique les nouveaux prix à tous les sièges correspondants dans la salle.
void updateSeatPrices(ConcertHall *hall, double priceA, double priceB, double priceC);

#endif // HALL_MANAGEMENT_H