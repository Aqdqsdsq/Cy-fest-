#include "seat_management.h"
#include "input_utils.h"
#include "display.h"
#include <stdio.h>

// Réserve un siège dans une salle de concert spécifiée par l'utilisateur.
// Cette fonction affiche toutes les salles, demande à l'utilisateur de choisir une salle,
// puis une rangée et un siège spécifiques à réserver.
void reserveSeat() {
    displayAllHalls();  // Affiche la liste des salles disponibles.
    
    // Demande à l'utilisateur de choisir l'indice de la salle où réserver un siège.
    int hallIndex = getIntInput("Choose the hall index for seat reservation: ", 0, numHalls - 1);
    displayHall(halls[hallIndex]);  // Affiche les détails de la salle choisie.
    
    // Demande l'indice de la rangée dans laquelle le siège sera réservé.
    int row = getIntInput("Enter the row number to reserve a seat in: ", 1, halls[hallIndex]->numRows) - 1;
    // Demande le numéro du siège à réserver dans la rangée choisie.
    int seat = getIntInput("Enter the seat number to reserve: ", 1, halls[hallIndex]->numSeatsPerRow[row]) - 1;

    // Vérifie si le siège est déjà réservé.
    if (halls[hallIndex]->seats[row][seat].reserved) {
        printf("This seat is already reserved.\n");
    } else {
        halls[hallIndex]->seats[row][seat].reserved = 1;  // Réserve le siège.
        printf("Seat reserved successfully.\n");
    }
}

// Annule la réservation d'un siège dans une salle spécifiée.
// Fonctionne de manière similaire à `reserveSeat`, mais pour l'annulation des réservations.
void cancelReservation() {
    displayAllHalls();  // Affiche toutes les salles pour aider à la sélection.
    
    // Demande à l'utilisateur de choisir l'indice de la salle pour l'annulation d'une réservation.
    int hallIndex = getIntInput("Choose the hall index to cancel a reservation: ", 0, numHalls - 1);
    displayHall(halls[hallIndex]);  // Affiche les détails de la salle sélectionnée.
    
    // Demande l'indice de la rangée où l'annulation est requise.
    int row = getIntInput("Enter the row number to cancel the reservation in: ", 1, halls[hallIndex]->numRows) - 1;
    // Demande le numéro du siège dont la réservation doit être annulée.
    int seat = getIntInput("Enter the seat number to cancel the reservation: ", 1, halls[hallIndex]->numSeatsPerRow[row]) - 1;

    // Vérifie si le siège n'est pas déjà réservé.
    if (!halls[hallIndex]->seats[row][seat].reserved) {
        printf("This seat is not currently reserved.\n");
    } else {
        halls[hallIndex]->seats[row][seat].reserved = 0;  // Annule la réservation du siège.
        printf("Reservation cancelled successfully.\n");
    }
}