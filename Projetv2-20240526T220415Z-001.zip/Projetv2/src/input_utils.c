#include "input_utils.h"
#include <stdio.h>

// Vide le tampon d'entrée pour éviter les erreurs de saisie.
// Cette fonction lit les caractères jusqu'à la fin de ligne ou jusqu'à la fin du fichier.
void clearInputBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);  // Lire et ignorer les caractères jusqu'à une nouvelle ligne ou EOF.
}

// Demande à l'utilisateur de saisir un entier dans un intervalle donné.
// Paramètres:
//   - prompt: Message à afficher à l'utilisateur.
//   - min: Valeur minimale acceptable.
//   - max: Valeur maximale acceptable.
// Retourne:
//   - Un entier validé dans l'intervalle [min, max].
// La fonction boucle jusqu'à ce que l'entrée soit valide et dans les limites spécifiées.
int getIntInput(const char *prompt, int min, int max) {
    int value;
    printf("%s", prompt);  // Affiche le message d'invite pour l'entrée.
    while (scanf("%d", &value) != 1 || value < min || value > max) {  // Vérifie que l'entrée est un entier et dans l'intervalle.
        clearInputBuffer();  // Vide le tampon d'entrée en cas d'erreur.
        printf("Entrée invalide. Veuillez entrer un nombre entier entre %d et %d.\n", min, max);  // Informe l'utilisateur de l'erreur.
    }
    clearInputBuffer();  // Nettoie le tampon d'entrée après une saisie valide pour éviter des problèmes ultérieurs.
    return value;  // Retourne la valeur entière valide.
}

// Demande à l'utilisateur de saisir un nombre décimal dans un intervalle donné.
// Paramètres:
//   - prompt: Message à afficher à l'utilisateur.
//   - min: Valeur minimale acceptable.
//   - max: Valeur maximale acceptable.
// Retourne:
//   - Un double validé dans l'intervalle [min, max].
// Cette fonction fonctionne de manière similaire à getIntInput, mais pour les entrées de type double.
double getDoubleInput(const char *prompt, double min, double max) {
    double value;
    printf("%s", prompt);  // Affiche le message d'invite pour l'entrée.
    while (scanf("%lf", &value) != 1 || value < min || value > max) {  // Vérifie que l'entrée est un double et dans l'intervalle.
        clearInputBuffer();  // Vide le tampon en cas d'entrée incorrecte.
        printf("Entrée invalide. Veuillez entrer un nombre décimal entre %.2f et %.2f.\n", min, max);  // Informe l'utilisateur de l'erreur.
    }
    clearInputBuffer();  // Nettoie le tampon d'entrée après une saisie valide.
    return value;  // Retourne la valeur double valide.
}