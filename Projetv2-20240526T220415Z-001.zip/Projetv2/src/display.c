#include "display.h"
#include <stdio.h>
#include <time.h>

// Affiche les détails d'une salle de concert spécifique.
// Affiche le nom de la salle, le nombre de rangées et l'état de chaque siège dans chaque rangée.
void displayHall(ConcertHall *hall) {
    if (!hall) return;  // Vérifie si le pointeur de la salle est non nul avant de continuer.
    
    printf("Hall: %s\n", hall->name);  // Affiche le nom de la salle.
    printf("Rows: %d\n", hall->numRows);  // Affiche le nombre de rangées de la salle.
    
    // Parcourt chaque rangée de la salle.
    for (int i = 0; i < hall->numRows; i++) {
        printf("Row %d: ", i + 1);  // Affiche le numéro de la rangée.
        
        // Parcourt chaque siège de la rangée pour afficher son état.
        for (int j = 0; j < hall->numSeatsPerRow[i]; j++) {
            if (hall->seats[i][j].reserved) {
                printf("%sX%s ", COLOR_RED, COLOR_RESET);  // Siège réservé, affiché en rouge.
            } else {
                printf("_ ");  // Siège disponible, affiché par un underscore.
            }
        }
        printf("\n");  // Nouvelle ligne après chaque rangée pour une meilleure lisibilité.
    }
}

// Affiche les informations sur toutes les salles gérées.
void displayAllHalls() {
    for (int i = 0; i < numHalls; i++) {
        printf("Index %d:\n", i);  // Indice de la salle dans le tableau global.
        displayHall(halls[i]);  // Appel de la fonction d'affichage pour chaque salle.
    }
}

// Affiche les concerts disponibles qui n'ont pas encore commencé.
void displayAvailableConcerts() {
    int found = 0;  // Indicateur pour vérifier si au moins un concert est disponible.
    time_t currentTime;  // Variable pour stocker le temps actuel.
    time(&currentTime);  // Obtention du temps courant.

    printf("\nAvailable Concerts:\n");
    
    // Parcourir toutes les salles pour vérifier les concerts à venir.
    for (int i = 0; i < numHalls; i++) {
        // Vérifie si la salle a un concert planifié et si la date/heure de fin n'est pas passée.
        if (halls[i]->concert != NULL && difftime(halls[i]->concert->endTime, currentTime) > 0) {
            found = 1;  // Un concert disponible a été trouvé.
            
            struct tm *endTime = localtime(&halls[i]->concert->endTime);  // Convertit la date/heure de fin en structure tm.
            char endTimeStr[100];  // Chaîne pour formater la date/heure de fin.
            strftime(endTimeStr, sizeof(endTimeStr), "%c", endTime);  // Formatage de la date/heure de fin.

            // Affiche les détails du concert.
            printf("Hall: %s\n", halls[i]->name);
            printf("Concert: %s\n", halls[i]->concert->name);
            printf("End Time: %s\n", endTimeStr);
        }
    }

    // Si aucun concert disponible n'est trouvé, informe l'utilisateur.
    if (!found) {
        printf("No available concerts at the moment.\n");
    }
}