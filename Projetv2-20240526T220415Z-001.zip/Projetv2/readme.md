# About

Ceci est un projet final pour l'année Pre Ing 1 MIM 1. Le but est de faire une Billeterie. [this pdf file](./P1-Info2_Project_CY-FEST_v1.0.pdf). The group is in [group](#group).

# Group

Aziz Ben Abdessalam

Wiktor WOJTAN

Caiazzo Cantareil Valentin

# Files

[main.c](./src/main.c) Le ficher principal, corps du programe. 

# Folder

Pour compiler et executer il faut :

cd ~/Desktop/Projetv2/src

gcc -Wall -g main.c input_utils.c file_operations.c hall_management.c seat_management.c display.c -o main

chmod +x main

./main


# CY Tech
![CY tech icon](./images/CY-Tech.png)