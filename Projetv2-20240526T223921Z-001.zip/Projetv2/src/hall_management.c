#include "hall_management.h"
#include "input_utils.h"
#include "types.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Initialise les sièges d'une rangée donnée dans une salle de concert.
// Paramètres:
//   - hall: Pointeur vers la structure ConcertHall représentant la salle.
//   - row: Indice de la rangée à initialiser.
//   - category: Catégorie des sièges pour cette rangée.
//   - price: Prix initial des sièges pour cette rangée.
// Effet:
//   - Tous les sièges de la rangée spécifiée sont initialisés avec la catégorie et le prix donnés.
void initializeSeats(ConcertHall *hall, int row, char category, double price) {
    for (int i = 0; i < hall->numSeatsPerRow[row]; i++) {
        hall->seats[row][i].category = category;
        hall->seats[row][i].price = price;
        hall->seats[row][i].reserved = 0;  // Initialise tous les sièges comme non réservés.
    }
}

// Crée une nouvelle salle de concert et l'ajoute à la liste globale des salles.
// Gère la saisie utilisateur pour le nom de la salle et le nombre de rangées et de sièges.
// Effet:
//   - Si le nombre maximum de salles est atteint, affiche un message et arrête la fonction.
//   - Sinon, alloue la mémoire pour une nouvelle salle et ses composants, les initialise et les ajoute à la liste.
void createConcertHall() {
    if (numHalls >= MAX_HALLS) {
        printf("Nombre maximum de salles atteint.\n");  // Limite de capacité atteinte, ne crée pas de nouvelle salle.
        return;
    }

    ConcertHall *newHall = (ConcertHall *)malloc(sizeof(ConcertHall));  // Allocation dynamique d'une nouvelle salle.
    if (!newHall) {
        perror("Échec de l'allocation de mémoire pour la nouvelle salle.");  // Gestion d'erreur si l'allocation échoue.
        exit(EXIT_FAILURE);
    }
    
    printf("Entrez le nom de la nouvelle salle de concert : ");
    fgets(newHall->name, MAX_NAME_LEN, stdin);
    newHall->name[strcspn(newHall->name, "\n")] = '\0';  // Suppression du caractère de nouvelle ligne.
    
    newHall->numRows = getIntInput("Entrez le nombre total de rangées : ", 1, MAX_SEATS_PER_ROW);
    newHall->numSeatsPerRow = (int *)malloc(sizeof(int) * newHall->numRows);
    newHall->seats = (Seat **)malloc(sizeof(Seat*) * newHall->numRows);

    for (int i = 0; i < newHall->numRows; i++) {
        printf("Entrez le nombre de sièges pour la rangée %d : ", i + 1);
        newHall->numSeatsPerRow[i] = getIntInput("", 1, MAX_SEATS_PER_ROW);
        newHall->seats[i] = (Seat *)malloc(sizeof(Seat) * newHall->numSeatsPerRow[i]);
        initializeSeats(newHall, i, CATEGORY_C, 20.0);  // Initialisation par défaut des sièges.
    }

    halls[numHalls++] = newHall;  // Ajoute la nouvelle salle à l'array global.
    printf("Salle '%s' créée avec succès.\n", newHall->name);
}

// Libère la mémoire allouée à une salle de concert spécifique.
// Paramètre:
//   - hall: Pointeur vers la salle de concert à libérer.
// Effet:
//   - Libère la mémoire de tous les composants de la salle puis la salle elle-même.
void freeConcertHall(ConcertHall *hall) {
    if (!hall) return;  // Vérifie si le pointeur de la salle n'est pas nul.
    for (int i = 0; i < hall->numRows; i++) {
        free(hall->seats[i]);  // Libère chaque rangée de sièges.
    }
    free(hall->seats);  // Libère le tableau de pointeurs vers les rangées de sièges.
    free(hall->numSeatsPerRow);  // Libère le tableau contenant le nombre de sièges par rangée.
    free(hall);  // Finalement, libère la structure de la salle elle-même.
}