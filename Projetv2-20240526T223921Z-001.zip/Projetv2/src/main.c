#include "types.h"
#include "display.h"
#include "hall_management.h"
#include "seat_management.h"
#include "file_operations.h"
#include "input_utils.h"
#include <stdio.h>

int numHalls = 0;  // Variable globale pour garder le nombre de salles actuellement gérées.

// Fonction principale du programme.
int main() {
    loadDataFromFile();  // Charge les données des salles depuis le fichier au démarrage du programme.

    int option;  // Variable pour stocker le choix de l'utilisateur dans le menu.
    do {
        // Affichage du menu principal.
        printf("\nMenu:\n");
        printf("1. Afficher toutes les salles\n");
        printf("2. Mode Manager\n");
        printf("3. Mode Festivalier\n");
        printf("4. Annuler reservation\n");
        printf("5. Exit\n");
        
        // Demande à l'utilisateur de choisir une option.
        option = getIntInput("Entrer votre choix: ", 1, 5);

        // Traitement du choix de l'utilisateur.
        switch (option) {
            case 1:
                displayAllHalls();  // Affiche les détails de toutes les salles.
                break;
            case 2:
                createConcertHall();  // Permet de créer une nouvelle salle.
                saveDataToFile();  // Sauvegarde les changements dans le fichier.
                break;
            case 3:
                reserveSeat();  // Permet au festivalier de réserver un siège.
                saveDataToFile();  // Sauvegarde les réservations dans le fichier.
                break;
            case 4:
                cancelReservation();  // Annule une réservation existante.
                saveDataToFile();  // Sauvegarde la mise à jour dans le fichier.
                break;
            case 5:
                printf("Exiting...\n");  // Quitte le programme.
                break;
            default:
                printf("Invalid option.\n");  // Gère le cas où l'option n'est pas valide.
                break;
        }
    } while (option != 5);  // Continue tant que l'utilisateur ne choisit pas de quitter.

    return 0;  // Fin du programme.
}