#ifndef SEAT_MANAGEMENT_H
#define SEAT_MANAGEMENT_H

#include "types.h"

// seat_management.h
// Ce fichier d'en-tête déclare les fonctions de gestion des réservations de sièges
// dans les salles de concert. Ces fonctions permettent de réserver et d'annuler des
// réservations de sièges, assurant ainsi une gestion efficace des places disponibles.

// Réserve un siège dans une salle de concert.
// Cette fonction permet à un utilisateur de choisir une salle, une rangée et un siège
// spécifique à réserver. Elle vérifie d'abord si le siège est disponible avant de
// marquer le siège comme réservé.
void reserveSeat();

// Annule la réservation d'un siège dans une salle de concert.
// Cette fonction permet à un utilisateur de choisir une salle, une rangée et un siège
// spécifique dont la réservation doit être annulée. Elle vérifie d'abord si le siège est
// effectivement réservé avant de marquer le siège comme disponible.
void cancelReservation();

#endif // SEAT_MANAGEMENT_H