#ifndef FILE_OPERATIONS_H
#define FILE_OPERATIONS_H

// file_operations.h
// Déclarations des fonctions pour la gestion des opérations de fichiers.
// Ce fichier contient les prototypes des fonctions utilisées pour sauvegarder et charger
// les données des salles de concert à partir de fichiers. Ces fonctions sont essentielles
// pour la persistance des données entre les sessions d'exécution du programme.

// Sauvegarde les données des salles de concert dans un fichier.
// Cette fonction ouvre le fichier "halls.dat" en mode écriture binaire, écrit les informations
// de toutes les salles enregistrées dans le système, puis ferme le fichier.
void saveDataToFile();

// Charge les données des salles de concert depuis un fichier.
// Ouvre le fichier "halls.dat" en mode lecture binaire. Si le fichier existe, lit les informations
// de toutes les salles et les stocke dans la mémoire dynamique. Si le fichier n'existe pas,
// un message est affiché et la fonction termine sans modifier l'état actuel des données en mémoire.
void loadDataFromFile();

#endif // FILE_OPERATIONS_H