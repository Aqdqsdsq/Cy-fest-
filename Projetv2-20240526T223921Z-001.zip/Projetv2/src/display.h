#ifndef DISPLAY_H
#define DISPLAY_H

// Inclusion des types structurés utilisés dans les déclarations de fonctions.
#include "types.h"

// Prototypes de fonctions pour l'affichage des informations des salles de concert.

// Affiche les détails d'une salle de concert spécifique.
// Paramètre 'hall' : pointeur vers la structure ConcertHall représentant la salle à afficher.
void displayHall(ConcertHall *hall);

// Parcourt et affiche les détails de toutes les salles de concert enregistrées.
// Utilise la fonction displayHall pour afficher chaque salle individuellement.
void displayAllHalls();

// Recherche et affiche les concerts disponibles qui n'ont pas encore eu lieu.
// Les concerts sont considérés disponibles si leur heure de fin est dans le futur.
void displayAvailableConcerts();

#endif // DISPLAY_H